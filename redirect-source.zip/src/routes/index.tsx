import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

/**
 * Invisible redirect handler for a Google Drive PDF.
 *
 * Browser restrictions to be aware of:
 * - Facebook's in-app WebView (Android & iOS) may silently block `intent://`
 *   launches, custom URL schemes and programmatic downloads. There is no
 *   reliable way to force an external app to open from inside it.
 * - iOS does not expose a documented deep link for opening a specific Drive
 *   file; `googledrive://` at best opens the app, never a guaranteed file view.
 * - Android Chrome usually honours the intent URL, but the OS can still block
 *   it if Drive is not installed (the intent has no browser_fallback_url here,
 *   so a failed launch simply does nothing).
 * Everything below therefore runs at most once and fails silently.
 */

const FILE_ID = "1toe08sgqO3a36DMiQm6H3g1bjT9CCwMA";

const VIEW_URL = `https://drive.google.com/file/d/${FILE_ID}/view`;
const DOWNLOAD_URL = `https://drive.google.com/uc?export=download&id=${FILE_ID}`;
const ANDROID_INTENT_URL = `intent://drive.google.com/file/d/${FILE_ID}/view#Intent;scheme=https;package=com.google.android.apps.docs;end`;
const IOS_APP_SCHEME = "googledrive://";

const ONCE_KEY = `drive-redirect:${FILE_ID}`;

/** Session flag + module flag: guards against StrictMode double-effects,
 *  multiple listeners and back-navigation re-entry. */
let ranInThisPageLoad = false;

function hasRun(): boolean {
  if (ranInThisPageLoad) return true;
  try {
    return sessionStorage.getItem(ONCE_KEY) === "1";
  } catch {
    // sessionStorage can throw in private/blocked contexts; module flag covers us.
    return false;
  }
}

function markRun(): void {
  ranInThisPageLoad = true;
  try {
    sessionStorage.setItem(ONCE_KEY, "1");
  } catch {
    /* ignore */
  }
}

/** Hidden iframe navigation: the least intrusive way to attempt a download or
 *  app launch without navigating the page away or opening a popup. */
function attempt(url: string): void {
  try {
    const frame = document.createElement("iframe");
    frame.style.display = "none";
    frame.src = url;
    document.body.appendChild(frame);
  } catch {
    /* blocked by the WebView — fail silently, no retry */
  }
}

function run(): void {
  if (hasRun()) return;
  markRun();

  const ua = navigator.userAgent || "";
  const isAndroid = /Android/i.test(ua);
  const isIOS =
    /iPhone|iPad|iPod/i.test(ua) ||
    // iPadOS 13+ reports as Mac; touch points disambiguate.
    (/Macintosh/.test(ua) && typeof document !== "undefined" && navigator.maxTouchPoints > 1);
  const isFacebook = /FBAN|FBAV|FB_IAB|FBIOS|FBSV/i.test(ua);

  if (isAndroid) {
    // 1. Download attempt (may be blocked inside the Facebook WebView).
    attempt(DOWNLOAD_URL);
    // 2. Single app-launch attempt shortly after; one timeout, never repeated.
    window.setTimeout(() => attempt(ANDROID_INTENT_URL), 800);
    return;
  }

  if (isIOS) {
    if (isFacebook) {
      // Facebook iOS WebView: a top-level navigation to the Drive view URL is
      // the only thing reliably permitted; iOS may then offer to open the app.
      window.location.href = VIEW_URL;
      return;
    }
    // Safari / other iOS browsers: one optional app-scheme attempt, then the
    // web viewer as the fallback. No loops.
    attempt(IOS_APP_SCHEME);
    window.setTimeout(() => {
      window.location.href = VIEW_URL;
    }, 700);
    return;
  }

  // Desktop and everything else: just go to the PDF.
  window.location.href = VIEW_URL;
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Document" },
      { name: "description", content: "Opening the requested PDF document." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Document" },
      { property: "og:description", content: "Opening the requested PDF document." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RedirectHandler,
});

function RedirectHandler() {
  useEffect(() => {
    run();
  }, []);

  // Intentionally renders nothing: no UI, no text, no styling.
  return null;
}
